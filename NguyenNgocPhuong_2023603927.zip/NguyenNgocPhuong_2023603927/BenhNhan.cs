﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NguyenNgocPhuong_2023603927
{
    public class BenhNhan
    {
        private string ma;
        private string hoTen;
        private DateTime ngay;
        private string loai;

        public string Ma { get => ma; set => ma=value; }
        public string HoTen { get => hoTen; set => hoTen=value; }
        public DateTime Ngay { get => ngay; set => ngay=value; }
        public string Loai { get => loai; set => loai=value; }

        public BenhNhan()
        {
            ma="";
            hoTen="";
            loai="";
        }

        public BenhNhan(string ma, string hoTen, DateTime ngay, string loai)
        {
            this.Ma=ma;
            this.HoTen=hoTen;
            this.Ngay=ngay;
            this.Loai=loai;
        }
    }
}
