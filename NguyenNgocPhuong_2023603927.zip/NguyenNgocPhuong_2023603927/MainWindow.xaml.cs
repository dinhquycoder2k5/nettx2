﻿using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace NguyenNgocPhuong_2023603927
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ObservableCollection<BenhNhan> dsBenhNhan;
        public MainWindow()
        {
            InitializeComponent();
            dsBenhNhan=new ObservableCollection<BenhNhan>();
            dg.ItemsSource=dsBenhNhan;

        }

        private void btnNhap_Click(object sender, RoutedEventArgs e)
        {
            string ma = txtMa.Text.Trim();
            if (string.IsNullOrEmpty(ma))
            {
                MessageBox.Show("Mã không để trống!", "Thông báo lỗi", MessageBoxButton.OK, MessageBoxImage.Warning);
                txtMa.Focus();
                return;
            }
            if (dsBenhNhan.FirstOrDefault(x => x.Ma==ma)!=null)
            {
                MessageBox.Show("Mã đã tồn tại", "Thông báo lỗi", MessageBoxButton.OK, MessageBoxImage.Warning);
                txtMa.Focus();
                return;
            }

            string hoTen = txtHoTen.Text.Trim();
            if (string.IsNullOrEmpty(hoTen))
            {
                MessageBox.Show("Họ tên không được để trống!", "Thông báo lỗi", MessageBoxButton.OK, MessageBoxImage.Warning);
                txtHoTen.Focus();
                return;
            }

            if (!dpNgay.SelectedDate.HasValue)
            {
                MessageBox.Show("Ngày vào viện không được để trống", "Thông báo lỗi", MessageBoxButton.OK, MessageBoxImage.Warning);
                dpNgay.Focus();
                return;
            }
            DateTime ngay = dpNgay.SelectedDate.Value;
            if (ngay>DateTime.Now.Date)
            {
                MessageBox.Show("Ngày vào viện phải nhỏ hơn hoặc bằng ngày hiện tại!", "Thông báo lỗi", MessageBoxButton.OK, MessageBoxImage.Warning);
                dpNgay.Focus();
                return;
            }

            string loai = cbLoaiBenh.Text;
            if (string.IsNullOrEmpty(loai))
            {
                MessageBox.Show("Loại bệnh nhân không để trống!", "Thông báo lỗi", MessageBoxButton.OK, MessageBoxImage.Warning);
                cbLoaiBenh.Focus();
                return;
            }

            dsBenhNhan.Add(new BenhNhan(ma, hoTen, ngay, loai));
            MessageBox.Show("Thêm bệnh nhân thành công!", "Thông báo", MessageBoxButton.OK, MessageBoxImage.Information);
            XoaForm();
        }

        private void XoaForm()
        {
            txtMa.Text="";
            txtHoTen.Text="";
            dpNgay.SelectedDate=null;
            cbLoaiBenh.SelectedIndex=-1;
            txtMa.Focus();
        }
        private void btnThongKe_Click(object sender, RoutedEventArgs e)
        {
            Window1 w = new Window1(dsBenhNhan.ToList());
            w.ShowDialog();
        }

        private void dg_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selected = dg.SelectedItem as BenhNhan;
            if (selected!=null)
            {
                txtMa.Text=selected.Ma;
                txtHoTen.Text=selected.HoTen;
                cbLoaiBenh.Text=selected.Loai;
                dpNgay.SelectedDate=selected.Ngay;
            }
        }
    }
}